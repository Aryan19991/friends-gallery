/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package universityenrollmentsystem;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;


public class UniversityTableGUI extends JFrame {
    
    JTable myTable;
    UniversityTableModel tableModel;
    ArrayList<Person> list;
    
    // contructor
    public UniversityTableGUI(ArrayList<Person> list){
        
        //set the title
        this.setTitle("People in University Enrollment System");
        
        // initialise and instantiate the instance variable 
        this.list = list;
        tableModel = new UniversityTableModel(list);
        myTable =  new JTable(tableModel);
        
        // set the size of the frame 
        setBounds(20,20,800,600); 
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Changed to DISPOSE to avoid closing main console
     
        // sorting
        myTable.setAutoCreateRowSorter(true);
      
        // add the table to the panel
        JScrollPane scrollPane = new JScrollPane(myTable); 
        scrollPane.setPreferredSize(new Dimension(380,280)); 

        // add a button on the bottom
        JButton button = new JButton("Statistics");
        
        GUIHandler handler = new GUIHandler();
        button.addActionListener(handler);
        
        // add the panel to the frame
        add(scrollPane,BorderLayout.CENTER); 
        add(button, BorderLayout.SOUTH);
    }
    
    private class GUIHandler implements ActionListener{
        int computerScience=0;
        int student=0;

        @Override 
        public void actionPerformed(ActionEvent e){
            for(int i=0; i<list.size();i++){
                if(list.get(i) instanceof Student s){
                    student++;
                    if(s.getCourseTitle().equalsIgnoreCase("Computer Science")){
                        computerScience++;
                    }
                }
            }
            if(student==0){
                JOptionPane.showMessageDialog(null,"No students in the list");
            }
            
            else{
                double percent = ((double) computerScience/student)*100;
                JOptionPane.showMessageDialog(null,"Percentage of Computer Science students: "+percent+"%");
            }
            
        }
    }
    
}

