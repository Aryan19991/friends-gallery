/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package universityenrollmentsystem;

/**
 *
 * @author LEGION
 */
public class TeachingAssistant extends Person{
    private int hoursPerWeek;
    private String supervisingModuleCode;
    
    public TeachingAssistant(String name, String surname){
        super(name, surname);
    }
    
//    Setter
    public void setHoursPerWeek(int hoursPerWeek){
        this.hoursPerWeek = hoursPerWeek;
    }
    
    public void setSupervisingModuleCode(String supervisingModuleCode){
        this.supervisingModuleCode = supervisingModuleCode;
    }
    
//    Getter
    public String getSupervisingModuleCode(){
        return this.supervisingModuleCode;
    }
    
    public int getHoursPerWeek(){
        return this.hoursPerWeek;
    }
    
    @Override
    public String toString(){
        return super.toString() + " Hours per week: "+hoursPerWeek+" Supervising Module Code: "+supervisingModuleCode;
    }
}
