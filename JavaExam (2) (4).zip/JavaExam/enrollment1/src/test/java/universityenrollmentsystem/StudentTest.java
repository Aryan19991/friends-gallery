/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package universityenrollmentsystem;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author LEGION
 */
public class StudentTest {
    Student student;
    public StudentTest() {
    }
    
    @BeforeEach
    public void setUp() {
        student = new Student("Ram", "Singh");
    }

    @Test
    public void testConstructor(){
    assertNotNull(student);
    }

    /**
     * Test of setModulesEnrolled and getModulesEnrolled methods, of class Student.
     */
    @Test
    public void testGetSetModulesEnrolled() {
        student.setModulesEnrolled(2);
        assertEquals(2,student.getModulesEnrolled());
    }


    /**
     * Test of toString method, of class Student.
     */
    @Test
    public void testToString() {
        student.setModulesEnrolled(1);
        String expected = 
                "Ram Singh, ID: null, DOB: N/A,  Student - Course: null, Modules Enrolled: 1";
        assertEquals(expected,student.toString());
                
    }
    
}
