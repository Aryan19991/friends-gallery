/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.hotelmanagementsystem;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author LEGION
 */
public class WestminsterHotelManagerIT {
    WestminsterHotelManager mySystem;
    public WestminsterHotelManagerIT() {
    }
    
    @BeforeEach
    public void setUp() {
        mySystem = new WestminsterHotelManager(2);
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of runMenu method, of class WestminsterHotelManager.
     */
    @Test
    public void testAddStaffToList() {
        //adding manager
        Manager m1 = new Manager("Ram", "Gopal");
        mySystem.addStaffToList(m1);
        
        Receptionist r1 = new Receptionist("Sita","Prasad");
        mySystem.addStaffToList(r1);
        
        HouseKeeper h1 = new HouseKeeper("Hari", "Dhakal");
        mySystem.addStaffToList(h1);
        
        assertEquals(2, mySystem.hotelStaffList.size());
        assertEquals(r1,mySystem.hotelStaffList.get(1));
    }
    
}
