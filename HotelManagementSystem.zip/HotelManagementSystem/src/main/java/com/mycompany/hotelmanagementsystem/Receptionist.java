/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hotelmanagementsystem;

/**
 *
 * @author LEGION
 */
public class Receptionist extends HotelStaff{
    
    //Instance Variables
    private String employeeLevel;
    private String shiftTiming;
    
    public Receptionist(String name, String surname){
        super(name, surname);
    }
    
    //Getters
    public String getEmployeeLevel(){
        return employeeLevel;
    }
    
    public String getShiftTiming(){
        return shiftTiming;
    }
    
    //Setters
    public void setEmployeeLevel(String employeeLevel){
        this.employeeLevel = employeeLevel;
    }
    
    public void setShiftTiming(String shiftTiming){
        this.shiftTiming = shiftTiming;
    }
    
    @Override
    public String toString(){
        return super.toString()+"Employee Level: "+employeeLevel+
                "Shift Timing: "+shiftTiming;
    }

}
