/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package universityenrollmentsystem;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author LEGION
 */
public class LecturerIT {
    Lecturer l;
    public LecturerIT() {
    }
    
    @BeforeEach
    public void setUp(){
        l = new Lecturer("Lect1","sur1");
    }
    @Test
    public void testConstructor() {
        
        assertNotNull(l);
    }
    
    
    

    /**
     * Test of setOfficeNumber method, of class Lecturer.
     */
    @Test
    public void testGetSetOfficeNumber() {
        l.setOfficeNumber(1);
        assertEquals(1,l.getOfficeNumber());
    }

  
    /**
     * Test of toString method, of class Lecturer.
     */
    @Test
    public void testToString() {
        String expected = 
                "Lect1 sur1, ID: null, DOB: N/A,  Lecturer - Office Number: 0, Specialisation: null";
        assertEquals(expected,l.toString());
    }
    
}
