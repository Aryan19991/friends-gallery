/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package universityenrollmentsystem;

/**
 *
 * @author LEGION
 */
public class Administrator extends Person{
    private int officeNumber;
    private String department;
    
    public Administrator(String name, String surname){
        super(name, surname);
    }
    
    public void setDepartment(String department){
        this.department = department;
    }
    public void setOfficeNumber(int officeNumber){
        this.officeNumber = officeNumber;
    }
    
    public String getDepartment(){
        return department;
    }
    public int getOfficeNumber(){
        return officeNumber;
    }
    
    @Override
    public String toString(){
        return super.toString()+"Department : "+department+" Office Number: "+officeNumber;
    }
}
